#include <DHT.h>

#define DHTPIN 2       // Pino de dados do sensor de temperatura
#define DHTTYPE DHT22  // Modelo do sensor
#define PORTA_PIN 3    // Pino do sensor de porta
#define BUZZER_PIN 8   // Pino do alarme sonoro

DHT dht(DHTPIN, DHTTYPE);

// Limite crítico de temperatura para o freezer (ex: -10 graus Celsius)
const float TEMP_MAXIMA = -10.0;

void setup() {
  Serial.begin(9600);
  dht.begin();
  pinMode(PORTA_PIN, INPUT_PULLUP); // Usa resistor interno do Arduino
  pinMode(BUZZER_PIN, OUTPUT);
}

void loop() {
  float temperatura = dht.readTemperature();
  // Se o pino estiver HIGH, a chave abriu (Porta Aberta = 1). Se LOW, Fechada = 0.
  int portaAberta = digitalRead(PORTA_PIN);

  if (isnan(temperatura)) {
    Serial.println("ERRO_SENSOR");
    delay(2000);
    return;
  }

  // Lógica de Alarme Local
  if (temperatura > TEMP_MAXIMA || portaAberta == 1) {
    tone(BUZZER_PIN, 1000); // Toca alarme de 1000Hz
  } else {
    noTone(BUZZER_PIN);     // Desliga alarme
  }

  // Envia os dados formatados em CSV pela porta Serial para o Python ler
  Serial.print(temperatura);
  Serial.print(",");
  Serial.println(portaAberta);

  delay(5000); // Lê a cada 5 segundos
}